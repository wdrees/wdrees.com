package com.example.android.googleBooks;

/**
 * Created by Administrator on 4/16/2018.
 */

interface EarthquakeAsyncTask {
}
